
import 'package:equatable/equatable.dart';
import 'package:mandirapp/common/network/app_constant.dart';
import 'package:mandirapp/main.dart';
import 'package:mandirapp/pages/auth/signin/data/entity/login_response.dart';
import 'package:mandirapp/pages/splash/presentation/bloc/splash_state.dart';

import '../../../../common/local/SharedPrefs.dart';
import '../../../../common/routes/exports.dart';
import '../../../../common/service_locator/setivelocator.dart';
import '../ui/app_initializer.dart';

part 'splash_event.dart';

class SplashBloc extends Bloc<SplashEvent, SplashState> {
  SplashBloc() : super(SplashInitial()) {
    on<StartTimerEvent>(startTimer);
  }

  Future<void> startTimer(
    StartTimerEvent event,
    Emitter<SplashState> emit,
  ) async
  {
    print("Starting timer...");

    final initialDataFuture = AppInitializer.loadInitialData(navigatorKey!.currentState!.context);
    final minSplashDuration = Future.delayed(const Duration(seconds: 3));

    // Wait until minimum splash duration has elapsed AND critical home data is ready
    await Future.wait([
      initialDataFuture,
      minSplashDuration,
    ]).timeout(
      const Duration(seconds: 5),
      onTimeout: () => [],
    );

    print("Timer finished. Critical Home data ready.");

    final prefs = getIt<SharedPrefs>();

    final token = await prefs.getString(AppConstant.token);
    final LoginResponse? userData = prefs.getModel<LoginResponse>(
      AppConstant.userModel,
      (json) => LoginResponse.fromJson(json),
    );

    if (token != null && token.trim().isNotEmpty && userData != null) {
      print("Token found");
      print("CHECKING HERE_______IN SPLASH\n\n");
      LogPrint(userData);
      LogPrint(userData.user.isProfileComplete);

      final bool isProfileComplete = userData.isProfileComplete;

      print("isProfileComplete => $isProfileComplete");

      if (userData.user.isProfileComplete == true) {
        emit(const SplashNavigateToHome());
      } else {
        emit(const SplashNavigatToProgileUpdate());
      }
    } else {
      print("User is not logged in");
      emit(const SplashNavigateToLogin());
    }
  }

  static void LogPrint(Object object) async {
    int defaultPrintLength = 1020;
    if (object == null || object.toString().length <= defaultPrintLength) {
      debugPrint(object.toString());
    } else {
      String log = object.toString();
      int start = 0;
      int endIndex = defaultPrintLength;
      int logLength = log.length;
      int tmpLogLength = log.length;
      while (endIndex < logLength) {
        debugPrint(log.substring(start, endIndex));
        endIndex += defaultPrintLength;
        start += defaultPrintLength;
        tmpLogLength -= defaultPrintLength;
      }
      if (tmpLogLength > 0) {
        debugPrint(log.substring(start, logLength));
      }
    }
  }
}
