import 'package:freezed_annotation/freezed_annotation.dart';

part 'onboarding_event.freezed.dart';

@freezed
abstract class OnboardingEvent with _$OnboardingEvent {
  const factory OnboardingEvent.started() = Started;
  const factory OnboardingEvent.pageChanged(int index) = PageChanged;
}
